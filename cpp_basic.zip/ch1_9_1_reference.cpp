#include<iostream>
using namespace std;
void func1_9() {
	int num1 = 1020;
	int &num2 = num1;

	num2 = 3047;
	cout << "VAL: " << num1 << endl;
	cout << "REF: " << num2 << endl;

	cout << "VAL: " << &num1 << endl;
	cout << "REF: " << &num2 << endl;
}

void func1_9_2_2() {
	double d = 3.1;
	double& ref = d;

	cout << d << endl;
	cout << ref << endl;

	cout << &d << endl;
	cout << &ref << endl;

}

//char�� ���� ch1�� �����ϰ� 'A'�� �ʱ�ȭ�Ѵ�
//���۷��� ���� ref1�� ref2�� ch1�� �����ϵ��� �Ѵ�
//���� �ڵ��� ��� �����?
void func1_9_2_1() {

	char c1 = 'A';
	char& ref1 = c1;
	char& ref2 = c1;

	cout << c1 << endl;
	cout << ref1 << endl;

	ref2++;

	cout << c1 << endl;
	cout << ref1 << endl;
}


void SwapByRef2(int& ref1, int& ref2)
{
	int temp = ref1;
	ref1 = ref2;
	ref2 = temp;
}

int test_swapByRef(void)
{
	int val1 = 10;
	int val2 = 20;

	SwapByRef2(val1, val2);
	cout << "val1: " << val1 << endl;
	cout << "val2: " << val2 << endl;
	return 0;
}

int& RefRetFuncOne(int& ref)
{
	ref++;
	return ref;
}

void test_RefRet1(void)
{
	int num1 = 1;
	int& num2 = RefRetFuncOne(num1);

	num1++;
	num2++;
	cout << "num1: " << num1 << endl;
	cout << "num2: " << num2 << endl;

	cout << "num1 �ּ�: " << &num1 << endl;
	cout << "num2 �ּ�: " << &num2 << endl;
}

void test_RefRet2() {
	int num1 = 1;
	int num2 = RefRetFuncOne(num1);

	num1++;
	num2++;
	cout << "num1: " << num1 << endl;
	cout << "num2: " << num2 << endl;

	cout << "num1 �ּ�: " << &num1 << endl;
	cout << "num2 �ּ�: " << &num2 << endl;

}
