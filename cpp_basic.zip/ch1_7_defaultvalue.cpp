#include <iostream>

int multiple(int num1 = 1, int num2 =2);

int adder(int num1 = 1, int num2 = 2) {

	return  num1 + num2;
}

int BoxVolume(int length, int width=1, int height=1)
{
	return length * width * height;
}


void func_boxVolume() {
	std::cout << "[3, 3, 3] : " << BoxVolume(3, 3, 3) << std::endl;
	std::cout << "[5, 5, D] : " << BoxVolume(5, 5) << std::endl;
	std::cout << "[7, D, D] : " << BoxVolume(7) << std::endl;
//	std::cout << "[D, D, D] : " << BoxVolume() << std::endl;

}

int multiple(int num1, int num2) {

	return num1 * num2;
}